
const send = require("../services/nodemailer")
const {generateVerificationCode, storeVerificationCode} = require('../services/verificationService')

const sendMail = async(req, res) => {
    /*const {to, subject, body} = req.body
    send(to, subject, body)

    return res.json('E-mail enviado com sucesso!')
}

module.exports = {
    sendMail
}*/

    const {to} = req.body
    const code = generateVerificationCode()
    storeVerificationCode(to, code)

    //Título do e-mail
    const subject = 'Seu código de verificação'
    //Corpo:
    const body = `Seu código de verificação é ${code}`

    try {
        await send(to, subject, body)
        return res.json('Código de verificação enviado com sucesso!')
    } catch (error) {
        return res.status(500).json("Erro ao enviar e-mail.")
    }
}

module.exports = {
    sendMail
}
