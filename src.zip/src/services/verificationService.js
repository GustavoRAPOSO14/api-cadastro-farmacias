
const crypto = require('crypto')

const generateVerificationCode = () => {
    //Gerando o código de verificação:
    return crypto.randomBytes(3).toString('hex')
}

const verificationCodes = {}

const storeVerificationCode = (email, code) => {
    verificationCodes[email] = {code, timestamp: Date.now()}
}

const verifyCode = (email, code) => {
    const record = verificationCodes[email]

    if (!record) return false

    const isExpired = (Date.now() - record.timestamp) > (10 * 60 * 1000)
    if (isExpired) {
        delete verificationCodes[email]
        return false
    }

    const isValid = record.code === code
    if (isValid) delete verificationCodes[email]
    
    return isValid
}

module.exports = {generateVerificationCode, storeVerificationCode, verifyCode}
