const express = require('express')
const {sendMail} = require('./controllers/mail.js')
const {verifyCode} = require('./services/verificationService')

/*const routes = express()

routes.post('/send', sendMail)

module.exports = routes*/

const router = express.Router()

router.post('/send-code', sendMail)

router.post('/verify-code', (req, res) => {
    const {email, code} = req.body

    if (verifyCode(email, code)) {
        return res.json('Código enviado com sucesso')
    } else {
        return res.status(400).json("Código inválido ou expirado.")
    }

})
